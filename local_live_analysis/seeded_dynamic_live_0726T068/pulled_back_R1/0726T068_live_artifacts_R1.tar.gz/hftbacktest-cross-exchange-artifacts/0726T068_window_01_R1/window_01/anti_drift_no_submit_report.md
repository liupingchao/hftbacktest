# 0623T007 Anti-Drift No-Submit Report

Watcher elapsed seconds: `1800.000864`
Anti-drift pass count: `14`
Anti-drift block count: `2`
Live submissions: `0`

No live order was submitted because candidates either did not pass fresh-touch gates or were blocked by the anti-drift / touch-stability gate.

Block reasons:
- `adverse_trade_pressure_with_recent_adverse_bbo`
- `adverse_trade_pressure_with_recent_adverse_bbo`
