# 0623T007 Anti-Drift No-Submit Report

Watcher elapsed seconds: `1800.000866`
Anti-drift pass count: `6`
Anti-drift block count: `1`
Live submissions: `0`

No live order was submitted because candidates either did not pass fresh-touch gates or were blocked by the anti-drift / touch-stability gate.

Block reasons:
- `adverse_trade_pressure_with_recent_adverse_bbo`
